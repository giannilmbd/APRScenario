#' KL function
#' APR suggest this measure to assess the "plausibility" of the conditional forecast.
#'
#' @param mu_eps mean of innovation
#' @param Sigma_eps variance of innovation
#'
#' @returns Returns the APR 'q': ie distance from a fair binomial distribution
#'
#' @export
#' @import dplyr
KL<-function(Sigma_eps,mu_eps,h){
  DKL<-parallel::mclapply(1:n_draws,FUN=function(d){
    0.5*(psych::tr(Sigma_eps[,,d])+t(mu_eps[,,d])%*%mu_eps[,,d]-n_var*h-log(det(Sigma_eps[,,d])))
  },mc.cores = parallel::detectCores()-1) %>% simplify2array()

  q<-parallel::mclapply(1:n_draws,FUN=function(d){0.5*(1+sqrt(1-exp(-2*DKL/h*n_var)))},
                        mc.cores = parallel::detectCores()-1) %>% simplify2array()
  return(q)
}

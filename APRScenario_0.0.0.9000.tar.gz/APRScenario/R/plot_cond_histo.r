#' plot_cond_histo function
#'
#' @param variable Name of variable to be plotted (string)
#' @param horizon At which horizon (horizon<=h)
#'
#' @returns ggplot object (plot)
#'
#' @export
#'
#' @import dplyr

plot_cond_histo<-function(variable=NULL,horizon=1){
  y_h_df<-as.data.frame(t(y_h))
  comby=paste(variable,horizon,sep='.')
  p<-ggplot(data=y_h_df)+geom_histogram(aes(x= !!sym(comby)),alpha=0.5)+
    labs(title=paste0('Distribution of forecast at horizon ',horizon))+theme_minimal()
  return(p)

  }
